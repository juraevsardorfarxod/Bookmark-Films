// function normalize date of film
function normalizeDate(evt) {
   let date=new Date(evt);
   let year=date.getFullYear();
   let month=String(date.getMonth()+1).padStart(2,0);
   let day=String(date.getDate()).padStart(2,0);
   return day+'.'+month+'.'+year;
};

// data submit to HTML
let newList=document.querySelector('.list');

function render(arr, node) {
   node.innerHTML=null;
   for(film of arr) {
      let newItem=document.createElement('li')
      newItem.setAttribute('class', 'list_item')
      
      let newPoster=document.createElement('img');
      let newTitle=document.createElement('h4');
      let lovely=document.createElement('button');
      
      newPoster.setAttribute('src', film.poster);
      newPoster.setAttribute('class', 'poster');
      lovely.setAttribute('class', 'lovely');
      lovely.dataset.lovelyId=film.id;
   
      newTitle.textContent=film.title;
      lovely.textContent='Bookmark';
   
      newItem.appendChild(newPoster);
      newItem.appendChild(newTitle);
      newItem.appendChild(lovely);
   
      node.appendChild(newItem);
   }
}

// Select Unikal Genres of All Genres
let newForm=document.querySelector('.newForm');
let newSelect=document.querySelector('.newSelect');

function generate(films, node) {
   let selectGenre=[];
   for(film of films) {
      for(genre of film.genres) {
         if(!selectGenre.includes(genre)) {
            selectGenre.push(genre);
         }
      } 
   };

   for(genre of selectGenre) {
      let newOption=document.createElement('option');
      newOption.textContent=genre;
      newOption.setAttribute('value', genre);
      newSelect.appendChild(newOption);
   };
}

newForm.addEventListener('submit', function(evt) {
   evt.preventDefault();
   let resultGenre=newSelect.value;
   let filteredFilms=[];
   if(resultGenre=='All') {
      filteredFilms=films;
   } else {
      filteredFilms=films.filter(function(film) {
         return film.genres.includes(resultGenre);
      });
   }
   render(filteredFilms, newList);
});

// ==================================== //
let bookMarksList=document.querySelector('.bookmarks');

function renderBookmarks(arr, node) {
   node.textContent=null;
   arr.forEach(element => {
      let newLi=document.createElement('li');
      let remove=document.createElement('button');
      remove.setAttribute('class', 'remove');
      remove.dataset.removeId=element.id;
      remove.textContent='remove';
      newLi.textContent=element.title;
      node.appendChild(newLi);
      node.appendChild(remove);
   });
}

let bookMarks=[];

newList.addEventListener('click', (evt)=>{
   evt.preventDefault();
   let lovelyFilm=evt.target.matches('.lovely');
   if(lovelyFilm) {
      let lovelyId=evt.target.dataset.lovelyId;
      let foundFilm=films.find(film=>film.id===lovelyId);
      if(!bookMarks.includes(foundFilm)) {
         bookMarks.push(foundFilm);

      }
   }
   renderBookmarks(bookMarks, bookMarksList);
});

bookMarksList.addEventListener('click', (evt)=>{
   evt.preventDefault();
   let remove=evt.target.matches('.remove');
   if(remove){
      let removeId=evt.target.dataset.removeId;
      let foundFilm=films.find(film=>film.id===removeId);
      bookMarks.shift(foundFilm);
   };
   renderBookmarks(bookMarks, bookMarksList);
});

renderBookmarks(bookMarks, bookMarksList);
render(films, newList);
generate(films, newSelect);
